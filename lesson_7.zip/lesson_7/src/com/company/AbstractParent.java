package com.company;

public abstract class AbstractParent{
    public AbstractParent(){
        System.out.println("Abstract Parent");
    }

    public abstract String getProfession();
}
