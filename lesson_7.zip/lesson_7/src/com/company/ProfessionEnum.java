package com.company;

public enum ProfessionEnum {
    BUILDER("Builder"),
    SOFTWARE_ENGINEER("Software Engineer");

    private String value;

    ProfessionEnum(String value) {
        this.value = value;
    }
}
