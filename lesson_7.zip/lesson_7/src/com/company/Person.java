package com.company;

public interface Person {
}
